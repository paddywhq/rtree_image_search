
#include "ColorHistogram.h"

#if ����

int main()
{
	string imgpath = IMGPATH;
	string filename = PATH + "imagelist.txt";

	ColorHistogram ch;
	ch.autowork(imgpath, filename, "output.txt");

	return 0;
}
#endif